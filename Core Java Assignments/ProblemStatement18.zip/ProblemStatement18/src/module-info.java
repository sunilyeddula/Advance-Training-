module ProblemStatement18 {
}