module ProblemStatement10 {
}