module ProblemStatement12 {
}