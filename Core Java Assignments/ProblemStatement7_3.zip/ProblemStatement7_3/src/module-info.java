module ProblemStatement7_3 {
	exports problemStatements7_3;
}