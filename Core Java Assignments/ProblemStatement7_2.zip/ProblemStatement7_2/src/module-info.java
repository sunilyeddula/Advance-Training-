module ProblemStatement7_2 {
}